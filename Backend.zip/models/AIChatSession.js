// models/AIChatSession.js - MongoDB model for AI chat sessions
const mongoose = require("mongoose");

const aiMessageSchema = new mongoose.Schema({
  role: {
    type: String,
    enum: ["user", "assistant"],
    required: true,
  },
  content: {
    type: String,
    required: true,
    maxlength: 2000,
  },
  timestamp: {
    type: Date,
    default: Date.now,
  },
  messageId: {
    type: String,
    default: () =>
      `msg_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
  },
});

const aiChatSessionSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
      index: true,
    },
    chatId: {
      type: String,
      required: true,
      unique: true,
      index: true,
    },
    title: {
      type: String,
      required: true,
      maxlength: 100,
      default: "New Chat",
    },
    aiMessages: [aiMessageSchema],
    isActive: {
      type: Boolean,
      default: true,
    },
    lastActivity: {
      type: Date,
      default: Date.now,
    },
    summary: {
      type: String,
      maxlength: 500,
    },
    tags: [
      {
        type: String,
        maxlength: 50,
      },
    ],
    diagnosticContext: {
      vehicleInfo: {
        make: String,
        model: String,
        year: Number,
      },
      primaryIssue: String,
      issueCategory: {
        type: String,
        enum: [
          "engine",
          "brake",
          "electrical",
          "transmission",
          "cooling",
          "fuel",
          "suspension",
          "other",
        ],
      },
      symptoms: [String],
      urgencyLevel: {
        type: String,
        enum: ["low", "medium", "high", "critical"],
        default: "medium",
      },
    },
    metadata: {
      deviceInfo: String,
      appVersion: String,
      totalMessages: {
        type: Number,
        default: 0,
      },
      avgResponseTime: Number,
      platform: String,
    },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

// Indexes for performance
aiChatSessionSchema.index({ userId: 1, lastActivity: -1 });
aiChatSessionSchema.index({ chatId: 1 });
aiChatSessionSchema.index({ createdAt: -1 });
aiChatSessionSchema.index({ "diagnosticContext.issueCategory": 1 });

// Virtual for message count
aiChatSessionSchema.virtual("messageCount").get(function () {
  return this.aiMessages.length;
});

// Virtual for conversation length (user-assistant pairs)
aiChatSessionSchema.virtual("conversationLength").get(function () {
  return Math.floor(this.aiMessages.length / 2);
});

// Virtual for preview text
aiChatSessionSchema.virtual("preview").get(function () {
  const firstUserMessage = this.aiMessages.find((msg) => msg.role === "user");
  if (firstUserMessage) {
    return (
      firstUserMessage.content.substring(0, 80) +
      (firstUserMessage.content.length > 80 ? "..." : "")
    );
  }
  return "New conversation";
});

// Pre-save middleware to update metadata
aiChatSessionSchema.pre("save", function (next) {
  this.lastActivity = new Date();
  this.metadata.totalMessages = this.aiMessages.length;

  // Auto-generate title from first user message if still default
  if (this.title === "New Chat" && this.aiMessages.length > 0) {
    const firstUserMessage = this.aiMessages.find((msg) => msg.role === "user");
    if (firstUserMessage) {
      this.title = this.generateTitle(firstUserMessage.content);
      this.extractDiagnosticContext(firstUserMessage.content);
    }
  }

  next();
});

// Method to generate smart title
aiChatSessionSchema.methods.generateTitle = function (firstMessage) {
  if (!firstMessage) return "New Chat";

  const message = firstMessage.toLowerCase();

  // Car-related keywords for smart titles
  const carKeywords = {
    engine: "Engine Issue",
    brake: "Brake Problem",
    battery: "Battery Issue",
    transmission: "Transmission Problem",
    oil: "Oil Issue",
    tire: "Tire Problem",
    steering: "Steering Issue",
    clutch: "Clutch Problem",
    radiator: "Cooling System",
    exhaust: "Exhaust Issue",
    alternator: "Electrical Problem",
    starter: "Starting Problem",
    fuel: "Fuel System",
    suspension: "Suspension Issue",
    "air conditioning": "AC Problem",
    ac: "AC Problem",
    headlight: "Lighting Issue",
    windshield: "Windshield Issue",
    dashboard: "Dashboard Issue",
    noise: "Strange Noise",
    sound: "Unusual Sound",
    ticking: "Ticking Sound",
    clicking: "Clicking Sound",
    grinding: "Grinding Noise",
    squealing: "Squealing Sound",
    leak: "Fluid Leak",
    smoke: "Smoke Issue",
    overheating: "Overheating",
    vibration: "Vibration Problem",
    "won't start": "Starting Problem",
    "hard to start": "Starting Issue",
  };

  // Find matching keyword
  for (const [keyword, title] of Object.entries(carKeywords)) {
    if (message.includes(keyword)) {
      return title;
    }
  }

  // Fallback to first few words
  const words = firstMessage.split(" ").slice(0, 4).join(" ");
  return words.length > 30 ? words.substring(0, 30) + "..." : words;
};

// Method to extract diagnostic context
aiChatSessionSchema.methods.extractDiagnosticContext = function (firstMessage) {
  const message = firstMessage.toLowerCase();

  // Determine issue category
  const categories = {
    engine: [
      "engine",
      "motor",
      "combustion",
      "cylinder",
      "piston",
      "crankshaft",
    ],
    brake: ["brake", "braking", "stop", "stopping", "pedal"],
    electrical: [
      "battery",
      "alternator",
      "starter",
      "electrical",
      "light",
      "radio",
      "dashboard",
    ],
    transmission: ["transmission", "gear", "shifting", "clutch"],
    cooling: ["radiator", "cooling", "coolant", "overheating", "temperature"],
    fuel: ["fuel", "gas", "gasoline", "injection", "carburetor"],
    suspension: ["suspension", "shock", "strut", "bounce", "rough ride"],
  };

  for (const [category, keywords] of Object.entries(categories)) {
    if (keywords.some((keyword) => message.includes(keyword))) {
      this.diagnosticContext.issueCategory = category;
      break;
    }
  }

  // Extract symptoms
  const symptoms = [];
  const symptomKeywords = [
    "noise",
    "sound",
    "ticking",
    "clicking",
    "grinding",
    "squealing",
    "leak",
    "smoke",
    "vibration",
    "shaking",
    "rough",
    "hard",
    "won't start",
    "difficult",
    "slow",
    "fast",
    "hot",
    "cold",
  ];

  symptomKeywords.forEach((symptom) => {
    if (message.includes(symptom)) {
      symptoms.push(symptom);
    }
  });

  this.diagnosticContext.symptoms = symptoms;

  // Determine urgency
  const urgentKeywords = [
    "won't start",
    "smoke",
    "fire",
    "emergency",
    "dangerous",
  ];
  const highKeywords = ["grinding", "no brakes", "overheating", "leak"];

  if (urgentKeywords.some((keyword) => message.includes(keyword))) {
    this.diagnosticContext.urgencyLevel = "critical";
  } else if (highKeywords.some((keyword) => message.includes(keyword))) {
    this.diagnosticContext.urgencyLevel = "high";
  }

  this.diagnosticContext.primaryIssue = firstMessage.substring(0, 200);
};

// Method to add message
aiChatSessionSchema.methods.addMessage = function (role, content) {
  this.aiMessages.push({
    role,
    content: content.trim(),
    timestamp: new Date(),
  });

  // Keep only last 40 messages to prevent bloat while maintaining context
  if (this.aiMessages.length > 40) {
    this.aiMessages = this.aiMessages.slice(-40);
  }

  return this.save();
};

// Method to get conversation context (optimized for AI)
aiChatSessionSchema.methods.getConversationContext = function (
  messageCount = 12
) {
  const recentMessages = this.aiMessages.slice(-messageCount);

  // If we have diagnostic context, include it in a structured way
  let contextSummary = "";
  if (this.diagnosticContext.primaryIssue) {
    contextSummary = `\n[DIAGNOSTIC CONTEXT]\n`;
    contextSummary += `Primary Issue: ${this.diagnosticContext.primaryIssue}\n`;
    if (this.diagnosticContext.issueCategory) {
      contextSummary += `Category: ${this.diagnosticContext.issueCategory}\n`;
    }
    if (this.diagnosticContext.symptoms.length > 0) {
      contextSummary += `Symptoms: ${this.diagnosticContext.symptoms.join(
        ", "
      )}\n`;
    }
    contextSummary += `Urgency: ${this.diagnosticContext.urgencyLevel}\n`;
    contextSummary += `[END CONTEXT]\n\n`;
  }

  return {
    messages: recentMessages,
    contextSummary,
    diagnosticInfo: this.diagnosticContext,
  };
};

// Static method to create new chat session
aiChatSessionSchema.statics.createNewSession = async function (
  userId,
  deviceInfo = {}
) {
  const chatId = `chat_${Date.now()}_${Math.random()
    .toString(36)
    .substr(2, 9)}`;

  const session = new this({
    userId,
    chatId,
    title: "New Chat",
    aiMessages: [],
    metadata: {
      deviceInfo: JSON.stringify(deviceInfo),
      appVersion: deviceInfo.appVersion || "1.0.0",
      platform: deviceInfo.platform || "unknown",
    },
  });

  return await session.save();
};

// Static method to get user's chat sessions
aiChatSessionSchema.statics.getUserSessions = async function (
  userId,
  limit = 20
) {
  return await this.find({
    userId,
    isActive: true,
  })
    .sort({ lastActivity: -1 })
    .limit(limit)
    .select(
      "chatId title lastActivity messageCount conversationLength createdAt preview diagnosticContext.issueCategory"
    )
    .lean();
};

// Static method to find session by chatId and userId
aiChatSessionSchema.statics.findByUserAndChatId = async function (
  userId,
  chatId
) {
  return await this.findOne({
    userId,
    chatId,
    isActive: true,
  });
};

// Static method to cleanup old sessions
aiChatSessionSchema.statics.cleanupOldSessions = async function () {
  const cutoffDate = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000); // 30 days

  const result = await this.updateMany(
    {
      lastActivity: { $lt: cutoffDate },
      isActive: true,
    },
    {
      isActive: false,
    }
  );

  console.log(`🧹 Cleaned up ${result.modifiedCount} old AI chat sessions`);
  return result;
};

// Static method to get analytics
aiChatSessionSchema.statics.getAnalytics = async function () {
  const analytics = await this.aggregate([
    { $match: { isActive: true } },
    {
      $group: {
        _id: null,
        totalSessions: { $sum: 1 },
        totalMessages: { $sum: "$metadata.totalMessages" },
        avgMessagesPerSession: { $avg: "$metadata.totalMessages" },
        issueCategories: { $push: "$diagnosticContext.issueCategory" },
      },
    },
  ]);

  return analytics[0] || {};
};

const AIChatSession = mongoose.model("AIChatSession", aiChatSessionSchema);

module.exports = AIChatSession;
