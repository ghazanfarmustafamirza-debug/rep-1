// services/chatbotService.js - Enhanced with MongoDB and better context management
const { GoogleGenerativeAI } = require("@google/generative-ai");
const AIChatSession = require("../models/AIChatSession");

// ================================
// ENHANCED CAR DIAGNOSTIC KNOWLEDGE BASE
// ================================
const CAR_DIAGNOSTIC_KNOWLEDGE = `
You are Fix My Car AI, an intelligent automotive diagnostic assistant for the Fix My Car mobile application. You provide professional car diagnostic consultations with expertise and precision.

CRITICAL INSTRUCTIONS:
- You are having a CONTINUOUS conversation with the user
- ALWAYS reference previous messages in the conversation when relevant
- DO NOT repeat the same questions you've already asked
- BUILD UPON previous information provided by the user
- Be PROGRESSIVE in your questioning - move forward, not backward
- If you've already asked about location, timing, etc., don't ask again unless clarifying

Your role:
- Professional automotive diagnostic consultant
- Analyze car symptoms and provide expert recommendations  
- Maintain helpful, knowledgeable, and professional tone
- Reference conversation history and build upon it
- Keep responses concise but informative for mobile interface
- Progress the conversation toward a solution

CONVERSATION FLOW RULES:
1. FIRST MESSAGE: Welcome and ask for the main issue
2. FOLLOW-UP: Build on their response with specific diagnostic questions
3. ANALYSIS: Provide diagnosis with confidence levels
4. SOLUTION: Offer actionable next steps
5. FOLLOW-UP: Check if they need more help with OTHER issues

DO NOT ASK THE SAME QUESTIONS REPEATEDLY!

INTERACTION PATTERNS:

GREETINGS & CASUAL:
- If user says: hi, hello, hey, good morning, etc. → Respond with friendly greeting and ask how you can help with their car
- If user says: how are you, what's up → Acknowledge and redirect to car assistance
- If user says: thank you, thanks → Acknowledge appreciation and offer further help
- If user says: bye, goodbye → Professional farewell and availability for future help

DIAGNOSTIC KNOWLEDGE:

ENGINE ISSUES:
- Car won't start + clicking sound = Dead battery (90% confidence)
- Car won't start + no sound = Starter motor failure (85% confidence)  
- Car won't start + engine cranks = Fuel/ignition system (80% confidence)
- Rough idle + shaking = Engine mounts, spark plugs, or fuel injectors
- Black smoke from exhaust = Rich fuel mixture, dirty air filter
- White smoke from exhaust = Coolant leak, head gasket issues
- Blue smoke from exhaust = Oil burning, worn piston rings
- Ticking sounds = Valve lifters, low oil, timing chain issues

BRAKE SYSTEM:
- Squealing when braking = Brake pad wear indicators (95% confidence)
- Grinding when braking = Brake pads completely worn (90% confidence)
- Soft/spongy brake pedal = Air in brake lines or brake fluid leak
- Vibration when braking = Warped brake rotors

ELECTRICAL ISSUES:
- Dashboard ticking = Turn signal relay, flasher unit, or HVAC actuator
- Clicking from dashboard = Blend door actuator or relay issues
- Random electrical ticking = Faulty relay or control module

TRANSMISSION:
- Slipping gears = Low transmission fluid or internal wear
- Hard shifting = Transmission fluid issues or clutch problems
- Burning smell + transmission issues = Overheated transmission fluid

COOLING SYSTEM:
- Engine overheating = Low coolant, thermostat, or radiator issues
- Sweet smell + overheating = Coolant leak
- Steam from hood = Coolant system failure

RESPONSE STYLE:
1. ACKNOWLEDGE what they've told you previously
2. BUILD UPON their information
3. Provide PROGRESSIVE diagnostic steps
4. Include confidence levels when diagnosing
5. Explain the reasoning behind diagnoses
6. Provide actionable next steps
7. Be clear about safety implications
8. Ask DIFFERENT follow-up questions that advance the diagnosis

EXAMPLE CONVERSATION FLOW:
User: "My car makes a ticking sound"
AI: "I can help diagnose that ticking sound. To pinpoint the issue, where exactly is the ticking coming from - the engine area or from inside the cabin/dashboard?"

User: "It's from the dashboard"
AI: "Dashboard ticking is typically an electrical issue. When does this ticking occur - constantly while the car is running, only when using certain features like A/C or turn signals, or intermittently?"

User: "Only when the AC is on"
AI: "That points to an HVAC blend door actuator issue (85% confidence). The ticking indicates the actuator motor is struggling to move the blend door..."

Always maintain professional consulting tone while being helpful and mobile-friendly.
REMEMBER: Progress the conversation, don't repeat previous questions!`;

// ================================
// ENHANCED CHATBOT SERVICE CLASS
// ================================
class ChatbotService {
  constructor() {
    if (!process.env.GEMINI_API_KEY) {
      throw new Error("GEMINI_API_KEY environment variable is required");
    }

    this.genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
    this.model = this.genAI.getGenerativeModel({
      model: "gemini-1.5-flash",
      generationConfig: {
        temperature: 0.4, // Slightly higher for more natural responses
        topK: 50,
        topP: 0.9,
        maxOutputTokens: 1000, // Increased for better responses
      },
    });

    // Fallback in-memory storage for guests
    this.guestConversations = new Map();

    // Start cleanup timer
    this.startCleanupTimer();

    console.log(
      "🤖 Enhanced ChatbotService with MongoDB initialized successfully"
    );
  }

  /**
   * Get all chat sessions for a user from MongoDB
   * @param {string} userId - User ID
   * @returns {Promise<Array>} - Array of chat sessions with metadata
   */
  async getUserChatSessions(userId) {
    if (!userId || userId.startsWith("guest_")) {
      return []; // Guests don't get persistent sessions
    }

    try {
      const sessions = await AIChatSession.getUserSessions(userId, 20);

      return sessions.map((session) => ({
        chatId: session.chatId,
        title: session.title,
        lastActivity: session.lastActivity,
        messageCount: session.conversationLength,
        preview: session.preview,
        createdAt: session.createdAt,
        issueCategory: session.diagnosticContext?.issueCategory,
      }));
    } catch (error) {
      console.error("Error fetching user chat sessions:", error);
      return [];
    }
  }

  /**
   * Create a new chat session
   * @param {string} userId - User ID
   * @param {Object} deviceInfo - Device information
   * @returns {Promise<string>} - New chat session ID
   */
  async createNewChatSession(userId, deviceInfo = {}) {
    if (!userId || userId.startsWith("guest_")) {
      // For guests, use in-memory storage
      const chatId = `chat_${Date.now()}_${Math.random()
        .toString(36)
        .substr(2, 9)}`;
      this.guestConversations.set(chatId, []);
      console.log(`💬 Created guest chat session: ${chatId}`);
      return chatId;
    }

    try {
      const session = await AIChatSession.createNewSession(userId, deviceInfo);
      console.log(
        `💬 Created new MongoDB chat session: ${session.chatId} for user: ${userId}`
      );
      return session.chatId;
    } catch (error) {
      console.error("Error creating new chat session:", error);
      throw new Error("Failed to create new chat session");
    }
  }

  /**
   * Get conversation history for a specific chat session
   * @param {string} userId - User ID
   * @param {string} chatId - Chat session ID
   * @returns {Promise<Array>} - Conversation history
   */
  async getChatConversation(userId, chatId) {
    if (!userId || !chatId) return [];

    if (userId.startsWith("guest_")) {
      // For guests, use in-memory storage
      return this.guestConversations.get(chatId) || [];
    }

    try {
      const session = await AIChatSession.findByUserAndChatId(userId, chatId);
      return session ? session.aiMessages : [];
    } catch (error) {
      console.error("Error fetching chat conversation:", error);
      return [];
    }
  }

  /**
   * Main method to get AI diagnosis with enhanced context
   * @param {string} userMessage - User's message describing car issue
   * @param {string} userId - User ID for conversation context
   * @param {string} chatId - Specific chat session ID
   * @returns {Promise<Object>} - Diagnosis response
   */
  async getDiagnosis(userMessage, userId, chatId = null) {
    try {
      // Validate input
      this.validateInput(userMessage);

      const sessionId = userId || `guest_${Date.now()}`;

      // Get or create chat session
      if (!chatId) {
        chatId = await this.createNewChatSession(sessionId);
      }

      // Get conversation context
      let conversationContext;
      let session = null;

      if (sessionId.startsWith("guest_")) {
        // Guest conversation
        const guestHistory = this.guestConversations.get(chatId) || [];
        conversationContext = {
          messages: guestHistory.slice(-10), // Keep last 10 for guests
          contextSummary: "",
          diagnosticInfo: null,
        };
      } else {
        // MongoDB conversation
        session = await AIChatSession.findByUserAndChatId(sessionId, chatId);
        if (!session) {
          session = await AIChatSession.createNewSession(sessionId);
          chatId = session.chatId;
        }
        conversationContext = session.getConversationContext(12);
      }

      console.log(
        `🔧 Processing diagnostic request for user: ${sessionId}, chat: ${chatId}`
      );

      // Build enhanced prompt with context
      const fullPrompt = this.buildEnhancedPrompt(
        userMessage,
        conversationContext
      );

      // Get AI response
      const result = await this.model.generateContent(fullPrompt);
      const response = result.response.text();

      // Save conversation
      if (sessionId.startsWith("guest_")) {
        // Guest storage
        let guestHistory = this.guestConversations.get(chatId) || [];
        guestHistory.push(
          { role: "user", content: userMessage.trim(), timestamp: new Date() },
          { role: "assistant", content: response, timestamp: new Date() }
        );
        // Keep only last 20 messages for guests
        if (guestHistory.length > 20) {
          guestHistory = guestHistory.slice(-20);
        }
        this.guestConversations.set(chatId, guestHistory);
      } else {
        // MongoDB storage
        await session.addMessage("user", userMessage);
        await session.addMessage("assistant", response);
      }

      const conversationLength = sessionId.startsWith("guest_")
        ? Math.floor((this.guestConversations.get(chatId)?.length || 0) / 2)
        : session?.conversationLength || 0;

      return {
        success: true,
        message: response,
        userId: sessionId,
        chatId: chatId,
        timestamp: new Date().toISOString(),
        conversationLength: conversationLength,
        hasContext: conversationContext.messages.length > 0,
      };
    } catch (error) {
      console.error("ChatbotService Error:", error);
      return this.handleError(error);
    }
  }

  /**
   * Delete a specific chat session
   * @param {string} userId - User ID
   * @param {string} chatId - Chat session ID to delete
   * @returns {Promise<boolean>} - Success status
   */
  async deleteChatSession(userId, chatId) {
    if (!userId || !chatId) return false;

    if (userId.startsWith("guest_")) {
      const deleted = this.guestConversations.delete(chatId);
      console.log(`🗑️ Guest chat session deleted: ${chatId}`);
      return deleted;
    }

    try {
      const session = await AIChatSession.findByUserAndChatId(userId, chatId);
      if (session) {
        session.isActive = false;
        await session.save();
        console.log(
          `🗑️ MongoDB chat session deleted: ${chatId} for user: ${userId}`
        );
        return true;
      }
      return false;
    } catch (error) {
      console.error("Error deleting chat session:", error);
      return false;
    }
  }

  /**
   * Clear all conversations for a user
   * @param {string} userId - User ID
   * @returns {Promise<boolean>} - Success status
   */
  async clearAllUserConversations(userId) {
    if (!userId) return false;

    if (userId.startsWith("guest_")) {
      // Clear all guest conversations (not ideal but possible)
      let cleared = false;
      for (const [chatId, conversation] of this.guestConversations.entries()) {
        if (chatId.includes(userId.split("_")[1])) {
          this.guestConversations.delete(chatId);
          cleared = true;
        }
      }
      return cleared;
    }

    try {
      const result = await AIChatSession.updateMany(
        { userId: userId, isActive: true },
        { isActive: false }
      );
      console.log(
        `🧹 All conversations cleared for user: ${userId}, count: ${result.modifiedCount}`
      );
      return result.modifiedCount > 0;
    } catch (error) {
      console.error("Error clearing user conversations:", error);
      return false;
    }
  }

  /**
   * Get service statistics
   * @returns {Promise<Object>} - Service stats
   */
  async getStats() {
    try {
      const mongoStats = await AIChatSession.getAnalytics();

      return {
        mongodb: {
          totalSessions: mongoStats.totalSessions || 0,
          totalMessages: mongoStats.totalMessages || 0,
          avgMessagesPerSession: mongoStats.avgMessagesPerSession || 0,
        },
        memory: {
          guestSessions: this.guestConversations.size,
          memoryUsage: JSON.stringify(
            Array.from(this.guestConversations.values())
          ).length,
        },
        uptime: process.uptime(),
      };
    } catch (error) {
      console.error("Error getting stats:", error);
      return {
        mongodb: { error: error.message },
        memory: {
          guestSessions: this.guestConversations.size,
          memoryUsage: JSON.stringify(
            Array.from(this.guestConversations.values())
          ).length,
        },
        uptime: process.uptime(),
      };
    }
  }

  // ================================
  // PRIVATE METHODS
  // ================================

  /**
   * Validate user input
   * @private
   */
  validateInput(userMessage) {
    if (!userMessage || typeof userMessage !== "string") {
      throw new Error("Valid message is required");
    }

    if (userMessage.trim().length === 0) {
      throw new Error("Message cannot be empty");
    }

    if (userMessage.length > 1000) {
      throw new Error("Message too long. Please keep under 1000 characters.");
    }
  }

  /**
   * Build enhanced prompt with conversation context
   * @private
   */
  buildEnhancedPrompt(userMessage, conversationContext) {
    let prompt = CAR_DIAGNOSTIC_KNOWLEDGE + "\n\n";

    // Add diagnostic context if available
    if (conversationContext.contextSummary) {
      prompt += conversationContext.contextSummary;
    }

    // Add conversation history
    if (conversationContext.messages.length > 0) {
      prompt += "CONVERSATION HISTORY (MOST RECENT):\n";
      conversationContext.messages.forEach((exchange, index) => {
        const role = exchange.role === "user" ? "User" : "Fix My Car AI";
        prompt += `${role}: ${exchange.content}\n`;
      });
      prompt += "\n";

      // Special instruction for context awareness
      prompt +=
        "IMPORTANT: You have the full conversation history above. Build upon what has been discussed. Do NOT repeat questions you've already asked. Progress the conversation toward a solution.\n\n";
    }

    prompt += `User's current message: "${userMessage.trim()}"\n\n`;

    if (conversationContext.messages.length === 0) {
      // First message in conversation
      prompt +=
        "This is the start of a new conversation. Provide a welcoming response and begin the diagnostic process.";
    } else {
      // Continuing conversation
      prompt +=
        "Continue the conversation by building upon previous messages. Reference what the user has already told you and progress toward a solution. DO NOT ask questions you've already asked.";
    }

    return prompt;
  }

  /**
   * Handle errors and return user-friendly messages
   * @private
   */
  handleError(error) {
    let errorMessage = "Sorry, I'm having trouble right now. Please try again.";

    if (error.message.includes("API key")) {
      errorMessage = "Diagnostic service is temporarily unavailable.";
    } else if (
      error.message.includes("too long") ||
      error.message.includes("characters")
    ) {
      errorMessage = error.message;
    } else if (error.message.includes("empty")) {
      errorMessage = "Please describe your car issue.";
    } else if (
      error.message.includes("quota") ||
      error.message.includes("limit")
    ) {
      errorMessage =
        "Service is temporarily busy. Please try again in a moment.";
    }

    return {
      success: false,
      error: errorMessage,
      timestamp: new Date().toISOString(),
    };
  }

  /**
   * Start periodic cleanup of old conversations
   * @private
   */
  startCleanupTimer() {
    // Clean up old guest conversations every hour
    const cleanupInterval = setInterval(() => {
      const cutoffTime = new Date(Date.now() - 24 * 60 * 60 * 1000); // 24 hours for guests
      let cleanedGuests = 0;

      for (const [chatId, conversation] of this.guestConversations.entries()) {
        if (conversation.length > 0) {
          const lastActivity = new Date(
            conversation[conversation.length - 1].timestamp
          );
          if (lastActivity < cutoffTime) {
            this.guestConversations.delete(chatId);
            cleanedGuests++;
          }
        }
      }

      if (cleanedGuests > 0) {
        console.log(`🧹 Cleaned up ${cleanedGuests} old guest conversations`);
      }

      // Clean up MongoDB sessions
      AIChatSession.cleanupOldSessions().catch(console.error);
    }, 60 * 60 * 1000); // Every hour

    // Ensure cleanup stops if process exits
    process.on("SIGTERM", () => clearInterval(cleanupInterval));
    process.on("SIGINT", () => clearInterval(cleanupInterval));
  }
}

// Export singleton instance
const chatbotService = new ChatbotService();
module.exports = chatbotService;
