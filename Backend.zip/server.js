const mongoose = require("mongoose");
const dotenv = require("dotenv");

// Load environment variables first
dotenv.config({ path: "./config.env" });

// Handle uncaught exceptions early
process.on("uncaughtException", (err) => {
  console.error("💥 UNCAUGHT EXCEPTION! Shutting down...");
  console.error("Error name:", err.name);
  console.error("Error message:", err.message);
  console.error("Stack trace:", err.stack);
  process.exit(1);
});

const app = require("./app");

// Configuration
const config = {
  port: process.env.PORT || 3000,
  nodeEnv: process.env.NODE_ENV || "development",
  mongoUrl: process.env.DATABASE?.replace(
    "<PASSWORD>",
    process.env.MONGODB_PASSWORD
  ),
  appName: "Fix My Car API",
};

// Validation
if (!config.mongoUrl) {
  console.error(
    "❌ DATABASE connection string is not defined in environment variables"
  );
  process.exit(1);
}

if (!process.env.MONGODB_PASSWORD) {
  console.error("❌ MONGODB_PASSWORD is not defined in environment variables");
  process.exit(1);
}

// Enhanced MongoDB connection with updated options for newer Mongoose versions
const connectDB = async () => {
  try {
    console.log("🔄 Connecting to MongoDB...");

    // Updated connection options - removed deprecated options
    const connectionOptions = {
      maxPoolSize: 10, // Maintain up to 10 socket connections
      serverSelectionTimeoutMS: 5000, // Keep trying to send operations for 5 seconds
      socketTimeoutMS: 45000, // Close sockets after 45 seconds of inactivity
      connectTimeoutMS: 10000, // Give up initial connection after 10 seconds
      family: 4, // Use IPv4, skip trying IPv6
    };

    // Only add legacy options if using Mongoose v5.x
    const mongooseVersion = mongoose.version;
    const majorVersion = parseInt(mongooseVersion.split(".")[0]);

    if (majorVersion < 6) {
      connectionOptions.useNewUrlParser = true;
      connectionOptions.useUnifiedTopology = true;
      connectionOptions.useCreateIndex = true;
      connectionOptions.useFindAndModify = false;
      connectionOptions.bufferMaxEntries = 0; // Only for v5.x
      connectionOptions.bufferCommands = false;
    }

    console.log(`📦 Using Mongoose version: ${mongooseVersion}`);

    const connection = await mongoose.connect(
      config.mongoUrl,
      connectionOptions
    );

    console.log(`✅ MongoDB Connected Successfully!`);
    console.log(`📍 Database Host: ${connection.connection.host}`);
    console.log(`🗄️  Database Name: ${connection.connection.name}`);

    return connection;
  } catch (error) {
    console.error("❌ MongoDB Connection Error:");
    console.error("Error name:", error.name);
    console.error("Error message:", error.message);

    // Additional debugging for connection issues
    if (error.name === "MongoParseError") {
      console.error(
        "🔧 This appears to be a connection string or option parsing error"
      );
      console.error(
        "🔗 Connection URL format should be: mongodb+srv://username:password@cluster.mongodb.net/database"
      );
    }

    // Exit process with failure
    process.exit(1);
  }
};

// Enhanced server startup
const startServer = async () => {
  try {
    // Connect to database first
    await connectDB();

    // Start the server
    const server = app.listen(config.port, () => {
      console.log("\n" + "=".repeat(50));
      console.log(`🚀 ${config.appName} Server Started Successfully!`);
      console.log(`📡 Port: ${config.port}`);
      console.log(`🌍 Environment: ${config.nodeEnv}`);
      console.log(`⏰ Started at: ${new Date().toISOString()}`);

      if (config.nodeEnv === "development") {
        console.log(`🔗 Local URL: http://localhost:${config.port}`);
        console.log(`📊 Health Check: http://localhost:${config.port}/health`);
        console.log(`📚 API Base: http://localhost:${config.port}/api`);
      } else {
        console.log(`🌐 Production server running on port ${config.port}`);
      }

      console.log("=".repeat(50) + "\n");
    });

    // Enhanced server error handling
    server.on("error", (error) => {
      if (error.syscall !== "listen") {
        throw error;
      }

      const bind =
        typeof config.port === "string"
          ? "Pipe " + config.port
          : "Port " + config.port;

      switch (error.code) {
        case "EACCES":
          console.error(`❌ ${bind} requires elevated privileges`);
          process.exit(1);
          break;
        case "EADDRINUSE":
          console.error(`❌ ${bind} is already in use`);
          process.exit(1);
          break;
        default:
          throw error;
      }
    });

    // Graceful shutdown handling
    const gracefulShutdown = (signal) => {
      console.log(`\n🛑 Received ${signal}. Starting graceful shutdown...`);

      server.close((err) => {
        console.log("🔌 HTTP server closed");

        mongoose.connection.close(false, () => {
          console.log("📦 MongoDB connection closed");
          console.log("✅ Graceful shutdown completed");
          process.exit(err ? 1 : 0);
        });
      });

      // Force close after 10 seconds
      setTimeout(() => {
        console.error(
          "⚠️  Could not close connections in time, forcefully shutting down"
        );
        process.exit(1);
      }, 10000);
    };

    // Handle different termination signals
    process.on("SIGTERM", () => gracefulShutdown("SIGTERM"));
    process.on("SIGINT", () => gracefulShutdown("SIGINT"));

    return server;
  } catch (error) {
    console.error("❌ Failed to start server:");
    console.error("Error name:", error.name);
    console.error("Error message:", error.message);
    console.error("Stack trace:", error.stack);
    process.exit(1);
  }
};

// MongoDB connection event handlers
mongoose.connection.on("connected", () => {
  console.log("📡 Mongoose connected to MongoDB");
});

mongoose.connection.on("error", (err) => {
  console.error("❌ Mongoose connection error:", err);
});

mongoose.connection.on("disconnected", () => {
  console.log("📡 Mongoose disconnected from MongoDB");
});

// Handle unhandled promise rejections
process.on("unhandledRejection", (err, promise) => {
  console.error("💥 UNHANDLED PROMISE REJECTION! Shutting down...");
  console.error("Error name:", err.name);
  console.error("Error message:", err.message);

  // Close server gracefully if it exists
  if (server) {
    server.close(() => {
      console.log("🔌 Process terminated due to unhandled promise rejection");
      process.exit(1);
    });
  } else {
    process.exit(1);
  }
});

// Additional process monitoring for production
if (config.nodeEnv === "production") {
  // Log memory usage periodically
  setInterval(() => {
    const memUsage = process.memoryUsage();
    const formatBytes = (bytes) =>
      Math.round((bytes / 1024 / 1024) * 100) / 100;

    console.log(
      `📊 Memory Usage: RSS=${formatBytes(memUsage.rss)}MB, Heap=${formatBytes(
        memUsage.heapUsed
      )}/${formatBytes(memUsage.heapTotal)}MB`
    );
  }, 300000); // Every 5 minutes
}

// Start the application
let server;
(async () => {
  server = await startServer();
})();

// Export server for testing purposes
module.exports = { app, server };
