const express = require("express");
const morgan = require("morgan");
const rateLimit = require("express-rate-limit");
const helmet = require("helmet");
const mongoSanitize = require("express-mongo-sanitize");
const xss = require("xss-clean");
const hpp = require("hpp");
const cookieParser = require("cookie-parser");
const cors = require("cors");
const compression = require("compression");

// Import route modules
const routes = {
  index: require("./routes/index"),
  users: require("./routes/users"),
  product: require("./routes/product"),
  review: require("./routes/review"),
  reviewMechanic: require("./routes/reviewMechanic"),
  conversation: require("./routes/conversation"),
  message: require("./routes/message"),
  booking: require("./routes/bookingRoute"),
  adminNotification: require("./routes/AdminNotificationRoute"),
  userNotification: require("./routes/UserNotificationRoute"),
  cart: require("./routes/cartRoute"),
  customerBuyingNotification: require("./routes/CustomerBuyingNotificationRoute"),
  customerMechanicNotification: require("./routes/CustomerMechanicNotification"),
  customerMechanicAfterAccepting: require("./routes/CustomerMechanicAfterAcceptingNotification"),
  mechanicAfterAccepting: require("./routes/MechanicAfterAcceptingNotification"),
  shopOwnerBuyingNotification: require("./routes/ShopOwnerBuyingNotificationRoute"),
  feedback: require("./routes/feedback"),
  faqs: require("./routes/faqs"),
  userReview: require("./routes/usereview"),
  car: require("./routes/carRoute"),
  chatbot: require("./routes/chatbot"),
};

// Import error handling middleware
const { globalErrorHandler, AppError } = require("./utils/errorHandler");

const app = express();

// ===========================================
// GLOBAL MIDDLEWARE CONFIGURATION
// ===========================================

// 1. Trust proxy (important for rate limiting and IP detection behind proxies)
app.set("trust proxy", 1);

// 2. Security headers - must be first
app.use(
  helmet({
    crossOriginEmbedderPolicy: false, // Allows embedding for mobile apps
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        scriptSrc: ["'self'"],
        imgSrc: ["'self'", "data:", "https:"],
      },
    },
  })
);

// 3. CORS configuration
const corsOptions = {
  origin: function (origin, callback) {
    // Allow requests with no origin (mobile apps, Postman, etc.)
    if (!origin) return callback(null, true);

    const allowedOrigins = [
      "http://localhost:3000",
      "http://localhost:3001",
      "http://localhost:8081", // React Native Metro bundler
      "https://yourdomain.com", // Add your production domain
    ];

    if (process.env.NODE_ENV === "development") {
      // Allow all origins in development
      return callback(null, true);
    }

    if (allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error("Not allowed by CORS"));
    }
  },
  credentials: true, // Allow cookies
  methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
  allowedHeaders: ["Content-Type", "Authorization", "X-Requested-With"],
};

app.use(cors(corsOptions));

// 4. Compression middleware for better performance
app.use(compression());

// 5. Body parsing middleware
app.use(
  express.json({
    limit: "10mb", // Increased for image uploads
    verify: (req, res, buf) => {
      // Store raw body for webhook verification if needed
      req.rawBody = buf;
    },
  })
);
app.use(express.urlencoded({ extended: true, limit: "10mb" }));

// 6. Cookie parser
app.use(cookieParser());

// 7. Security middleware order is important
// Data sanitization against NoSQL query injection
app.use(mongoSanitize());

// Data sanitization against XSS attacks
app.use(xss());

// Prevent parameter pollution
app.use(
  hpp({
    whitelist: ["sort", "fields", "page", "limit"], // Allow these duplicate params
  })
);

// ===========================================
// RATE LIMITING CONFIGURATION
// ===========================================

// General rate limiter
const generalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 1000, // Increased for mobile app usage
  message: {
    status: "error",
    message: "Too many requests from this IP, please try again later.",
  },
  standardHeaders: true,
  legacyHeaders: false,
  handler: (req, res) => {
    res.status(429).json({
      status: "error",
      message: "Too many requests from this IP, please try again later.",
      retryAfter: Math.round(req.rateLimit.resetTime / 1000),
    });
  },
});

// Strict rate limiter for authentication endpoints
const authLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 10, // Much stricter for auth endpoints
  message: {
    status: "error",
    message: "Too many authentication attempts, please try again in an hour.",
  },
  skipSuccessfulRequests: true, // Don't count successful requests
});

// API limiter for general API usage
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 500, // 500 requests per 15 minutes per IP
  message: {
    status: "error",
    message: "API rate limit exceeded, please try again later.",
  },
});

// Apply rate limiters
app.use("/api/", apiLimiter);
app.use("/users/signin", authLimiter);
app.use("/users/signup", authLimiter);
app.use("/users/forgotPassword", authLimiter);
app.use("/users/", generalLimiter);

app.use((req, res, next) => {
  req.requestTime = new Date().toISOString();
  req.requestId = Math.random().toString(36).substr(2, 9); // Simple request ID

  // Add request context for debugging
  if (process.env.NODE_ENV === "development") {
    console.log(
      `🔍 [${req.requestId}] ${req.method} ${req.originalUrl} - ${req.ip}`
    );
  }

  next();
});

// Health check endpoint (before other routes)
app.get("/health", (req, res) => {
  res.status(200).json({
    status: "success",
    message: "Fix My Car API is healthy",
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    environment: process.env.NODE_ENV,
  });
});

// API version endpoint
app.get("/api", (req, res) => {
  res.status(200).json({
    status: "success",
    message: "Welcome to Fix My Car API",
    version: "1.0.0",
    documentation: "/api/docs",
    endpoints: {
      users: "/users",
      products: "/product",
      reviews: "/review",
      bookings: "/booking",
      notifications: "/adminNotification",
    },
  });
});

// ===========================================
// ROUTE CONFIGURATION
// ===========================================

// Core application routes
app.use("/", routes.index);
app.use("/users", routes.users);
app.use("/product", routes.product);
app.use("/review", routes.review);
app.use("/reviewMechanic", routes.reviewMechanic);
app.use("/conversation", routes.conversation);
app.use("/message", routes.message);
app.use("/booking", routes.booking);
app.use("/car", routes.car);

// Notification routes - grouped by functionality
app.use("/adminNotification", routes.adminNotification);
app.use("/userNotification", routes.userNotification);
app.use("/CustomerBuyingNotificationRoute", routes.customerBuyingNotification);
app.use(
  "/ShopOwnerBuyingNotificationRoute",
  routes.shopOwnerBuyingNotification
);
app.use("/MechanicNotificationRoute", routes.customerMechanicNotification);
app.use(
  "/CustomerMechanicAfterAcceptingNotification",
  routes.customerMechanicAfterAccepting
);
app.use("/MechanicAfterAcceptingNotification", routes.mechanicAfterAccepting);

// Support and feedback routes
app.use("/cart", routes.cart);
app.use("/feedback", routes.feedback);
app.use("/faqs", routes.faqs);
app.use("/userreview", routes.userReview);
app.use("/chatbot", routes.chatbot);

// ===========================================
// ERROR HANDLING MIDDLEWARE
// ===========================================

// 404 handler for unmatched routes
app.all("*", (req, res, next) => {
  const error = new AppError(
    `Can't find ${req.originalUrl} on this server. Available endpoints: /api`,
    404
  );

  // Log 404s for analysis
  if (process.env.NODE_ENV === "development") {
    console.log(`❌ 404 - ${req.method} ${req.originalUrl} from ${req.ip}`);
  }

  next(error);
});

// Global error handling middleware
app.use(globalErrorHandler);

// ===========================================
// GRACEFUL ERROR HANDLING
// ===========================================

// Handle uncaught exceptions in routes
process.on("uncaughtException", (err) => {
  console.error("💥 UNCAUGHT EXCEPTION in app.js:", err.name, err.message);
  console.error("Stack:", err.stack);
  process.exit(1);
});

// Handle unhandled promise rejections
process.on("unhandledRejection", (err) => {
  console.error("💥 UNHANDLED REJECTION in app.js:", err.name, err.message);
  console.error("Stack:", err.stack);
});

// ===========================================
// EXPORT APPLICATION
// ===========================================

module.exports = app;
