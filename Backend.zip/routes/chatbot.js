// routes/chatbot.js
var express = require("express");
var router = express.Router();
const rateLimit = require("express-rate-limit");
const jwt = require("jsonwebtoken");
const User = require("../models/loginModel"); // Your actual User model

const chatbotController = require("../controller/chatbotController");

// ================================
// AUTHENTICATION MIDDLEWARE (Built-in)
// ================================

/**
 * Protect middleware - requires authentication
 * Works with your actual User model and database
 */
const protect = async (req, res, next) => {
  try {
    // 1) Getting token and check if it's there
    let token;
    if (
      req.headers.authorization &&
      req.headers.authorization.startsWith("Bearer")
    ) {
      token = req.headers.authorization.split(" ")[1];
    }

    if (!token) {
      return res.status(401).json({
        status: "fail",
        message: "You are not logged in! Please log in to get access.",
        code: "NO_TOKEN",
      });
    }

    // 2) Verification token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    // 3) Check if user still exists in database
    const currentUser = await User.findById(decoded.id).select("+password");
    if (!currentUser) {
      return res.status(401).json({
        status: "fail",
        message: "The user belonging to this token does no longer exist.",
        code: "USER_NOT_FOUND",
      });
    }

    // 4) Check if user changed password after the token was issued
    if (
      currentUser.changePasswordAfter &&
      currentUser.changePasswordAfter(decoded.iat)
    ) {
      return res.status(401).json({
        status: "fail",
        message: "User recently changed password! Please log in again.",
        code: "PASSWORD_CHANGED",
      });
    }

    // 5) Check if user account is active
    if (currentUser.active !== "active") {
      return res.status(401).json({
        status: "fail",
        message: `Your account is ${currentUser.active}. Please contact support.`,
        code: "ACCOUNT_INACTIVE",
        accountStatus: currentUser.active,
      });
    }

    // Grant access to protected route
    req.user = currentUser;
    console.log(
      `🔐 User authenticated: ${currentUser.firstname} ${currentUser.lastname} (${currentUser.role})`
    );
    next();
  } catch (error) {
    console.error("🔒 Auth error:", error.message);

    if (error.name === "JsonWebTokenError") {
      return res.status(401).json({
        status: "fail",
        message: "Invalid token. Please log in again.",
        code: "INVALID_TOKEN",
      });
    } else if (error.name === "TokenExpiredError") {
      return res.status(401).json({
        status: "fail",
        message: "Your token has expired. Please log in again.",
        code: "TOKEN_EXPIRED",
      });
    } else if (error.name === "CastError") {
      return res.status(401).json({
        status: "fail",
        message: "Invalid user ID in token.",
        code: "INVALID_USER_ID",
      });
    } else {
      return res.status(500).json({
        status: "error",
        message: "Authentication service error. Please try again.",
        code: "AUTH_SERVICE_ERROR",
      });
    }
  }
};

/**
 * Optional auth middleware - doesn't fail if no auth
 * Tries to authenticate with real database lookup
 */
const optionalAuth = async (req, res, next) => {
  try {
    // Try to authenticate but don't fail if no token
    const authHeader = req.headers.authorization;

    if (authHeader && authHeader.startsWith("Bearer ")) {
      const token = authHeader.split(" ")[1];

      try {
        // Try to verify token
        const decoded = jwt.verify(token, process.env.JWT_SECRET);

        // Try to find user in database
        const currentUser = await User.findById(decoded.id);

        if (currentUser && currentUser.active === "active") {
          // Check if password changed after token
          if (
            currentUser.changePasswordAfter &&
            currentUser.changePasswordAfter(decoded.iat)
          ) {
            console.log("🔓 Password changed after token, continuing as guest");
            req.user = null;
          } else {
            req.user = currentUser;
            console.log(
              `🔐 User authenticated: ${currentUser.firstname} ${currentUser.lastname} (${currentUser.role})`
            );
          }
        } else {
          console.log("🔓 User not found or inactive, continuing as guest");
          req.user = null;
        }
      } catch (authError) {
        // Auth failed, but continue as guest
        console.log("🔓 Auth failed, continuing as guest:", authError.message);
        req.user = null;
      }
    } else {
      // No auth header, continue as guest
      console.log("🔓 No auth header, continuing as guest");
      req.user = null;
    }

    next();
  } catch (error) {
    // Any unexpected error, continue as guest
    console.log(
      "🔓 Unexpected auth error, continuing as guest:",
      error.message
    );
    req.user = null;
    next();
  }
};

// ================================
// RATE LIMITING CONFIGURATION
// ================================

// Rate limiter for authenticated users (generous limits)
const authenticatedUserLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 50, // 50 requests per 15 minutes for authenticated users
  message: {
    status: "fail",
    message: "Too many chatbot requests. Please wait before trying again.",
    code: "RATE_LIMIT_EXCEEDED",
    accountType: "authenticated",
  },
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => {
    // Use user ID for authenticated users
    return req.user ? `auth_${req.user._id}` : `ip_${req.ip}`;
  },
  handler: chatbotController.rateLimitHandler,
});

// Stricter rate limiter for guest users
const guestUserLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10, // 10 requests per 15 minutes for guests
  message: {
    status: "fail",
    message: "Guest limit reached. Please sign up for unlimited access.",
    code: "GUEST_LIMIT_EXCEEDED",
    accountType: "guest",
  },
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => `guest_${req.ip}`,
  handler: chatbotController.rateLimitHandler,
});

// Flexible limiter for the flexible endpoint
const flexibleLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: (req) => {
    // Dynamic limits based on authentication status
    return req.user ? 50 : 10;
  },
  message: {
    status: "fail",
    message: "Too many requests. Please wait before trying again.",
    code: "RATE_LIMIT_EXCEEDED",
  },
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => {
    return req.user ? `flex_auth_${req.user._id}` : `flex_guest_${req.ip}`;
  },
  handler: chatbotController.rateLimitHandler,
});

// Admin-only limiter (higher limits)
const adminLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // 100 requests per 15 minutes for admins
  message: {
    status: "fail",
    message: "Admin rate limit exceeded.",
    code: "ADMIN_RATE_LIMIT_EXCEEDED",
  },
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => `admin_${req.user?._id || req.ip}`,
  handler: chatbotController.rateLimitHandler,
});

// ================================
// CHATBOT ROUTES
// ================================

/**
 * @route   GET /chatbot/health
 * @desc    Health check for chatbot service
 * @access  Public
 */
router.get("/health", chatbotController.healthCheck);

/**
 * @route   GET /chatbot/debug/auth
 * @desc    Debug authentication status
 * @access  Public
 */
router.get("/debug/auth", optionalAuth, chatbotController.debugAuth);

/**
 * @route   POST /chatbot/diagnose
 * @desc    Get AI diagnosis for car issues (authenticated users only)
 * @access  Protected
 * @body    { message: string, chatId?: string }
 */
router.post(
  "/diagnose",
  authenticatedUserLimiter,
  protect,
  chatbotController.validateMessageInput,
  chatbotController.getDiagnosis
);

/**
 * @route   POST /chatbot/diagnose-guest
 * @desc    Get AI diagnosis for car issues (guest users only)
 * @access  Public (with stricter rate limiting)
 * @body    { message: string, guestId?: string, chatId?: string }
 */
router.post(
  "/diagnose-guest",
  guestUserLimiter,
  chatbotController.validateMessageInput,
  chatbotController.getGuestDiagnosis
);

/**
 * @route   POST /chatbot/diagnose-flexible
 * @desc    Get AI diagnosis - works with or without authentication (RECOMMENDED)
 * @access  Flexible (Public/Protected)
 * @body    { message: string, guestId?: string, chatId?: string }
 */
router.post(
  "/diagnose-flexible",
  flexibleLimiter,
  optionalAuth,
  chatbotController.validateMessageInput,
  chatbotController.getFlexibleDiagnosis
);

/**
 * @route   GET /chatbot/history
 * @desc    Get conversation history for current user (all chats or specific chat)
 * @access  Protected
 * @query   chatId (optional) - Get specific chat conversation
 */
router.get(
  "/history",
  authenticatedUserLimiter,
  protect,
  chatbotController.getConversationHistory
);

/**
 * @route   GET /chatbot/analytics
 * @desc    Get user's chatbot usage analytics
 * @access  Protected
 */
router.get(
  "/analytics",
  authenticatedUserLimiter,
  protect,
  chatbotController.getUserAnalytics
);

/**
 * @route   POST /chatbot/new-chat
 * @desc    Create a new chat session
 * @access  Protected
 * @body    { deviceInfo?: object }
 */
router.post(
  "/new-chat",
  authenticatedUserLimiter,
  protect,
  chatbotController.createNewChat
);

/**
 * @route   DELETE /chatbot/chat/:chatId
 * @desc    Delete a specific chat session
 * @access  Protected
 * @param   chatId - Chat session ID to delete
 */
router.delete(
  "/chat/:chatId",
  authenticatedUserLimiter,
  protect,
  chatbotController.deleteChatSession
);

/**
 * @route   DELETE /chatbot/clear
 * @desc    Clear conversation history (specific chat or all chats)
 * @access  Protected
 * @query   chatId (optional) - Clear specific chat, omit to clear all
 */
router.delete(
  "/clear",
  authenticatedUserLimiter,
  protect,
  chatbotController.clearConversationHistory
);

/**
 * @route   GET /chatbot/stats
 * @desc    Get comprehensive chatbot service statistics
 * @access  Protected + Admin only
 */
router.get("/stats", adminLimiter, protect, chatbotController.getServiceStats);

// ================================
// WEBHOOK & ADMIN ROUTES
// ================================

/**
 * @route   POST /chatbot/webhook/cleanup
 * @desc    Manual trigger for cleanup operations
 * @access  Protected + Admin only
 */
router.post("/webhook/cleanup", adminLimiter, protect, async (req, res) => {
  // Check admin privileges
  if (req.user.role !== "admin" && req.user.role !== "Admin") {
    return res.status(403).json({
      status: "fail",
      message: "Admin privileges required",
      code: "INSUFFICIENT_PRIVILEGES",
    });
  }

  try {
    console.log(`🧹 Manual cleanup triggered by admin ${req.user._id}`);

    // This would trigger manual cleanup in your chatbot service
    // You can implement this in your chatbot service

    res.status(200).json({
      status: "success",
      data: {
        message: "Cleanup operation triggered successfully",
        triggeredBy: {
          userId: req.user._id,
          name: `${req.user.firstname} ${req.user.lastname}`,
          role: req.user.role,
        },
        timestamp: new Date().toISOString(),
      },
    });
  } catch (error) {
    console.error("❌ Manual cleanup failed:", error);
    res.status(500).json({
      status: "error",
      message: "Cleanup operation failed",
      error: error.message,
    });
  }
});

/**
 * @route   GET /chatbot/metrics
 * @desc    Get real-time metrics for monitoring
 * @access  Protected + Admin only
 */
router.get("/metrics", adminLimiter, protect, async (req, res) => {
  // Check admin privileges
  if (req.user.role !== "admin" && req.user.role !== "Admin") {
    return res.status(403).json({
      status: "fail",
      message: "Admin privileges required",
      code: "INSUFFICIENT_PRIVILEGES",
    });
  }

  try {
    const chatbotService = require("../services/chatbotService");
    const stats = await chatbotService.getStats();

    // Enhanced metrics for monitoring
    const metrics = {
      ...stats,
      system: {
        uptime: process.uptime(),
        memory: process.memoryUsage(),
        cpuUsage: process.cpuUsage(),
        platform: process.platform,
        nodeVersion: process.version,
      },
      environment: {
        nodeEnv: process.env.NODE_ENV,
        hasRequiredEnvVars: {
          jwtSecret: !!process.env.JWT_SECRET,
          geminiApiKey: !!process.env.GEMINI_API_KEY,
          mongoUri: !!process.env.MONGO_URI,
        },
      },
      requestInfo: {
        requestedBy: {
          userId: req.user._id,
          name: `${req.user.firstname} ${req.user.lastname}`,
          role: req.user.role,
        },
        timestamp: new Date().toISOString(),
      },
    };

    res.status(200).json({
      status: "success",
      data: metrics,
    });
  } catch (error) {
    console.error("❌ Metrics request failed:", error);
    res.status(500).json({
      status: "error",
      message: "Failed to retrieve metrics",
      error: error.message,
    });
  }
});

// ================================
// ERROR HANDLING MIDDLEWARE
// ================================

// Global error handler for chatbot routes
router.use((error, req, res, next) => {
  console.error("🚨 Chatbot route error:", error);

  // Handle specific error types
  if (error.name === "ValidationError") {
    return res.status(400).json({
      status: "fail",
      message: "Validation error",
      code: "VALIDATION_ERROR",
      details: error.message,
    });
  }

  if (error.name === "CastError") {
    return res.status(400).json({
      status: "fail",
      message: "Invalid ID format",
      code: "INVALID_ID",
    });
  }

  if (error.code === 11000) {
    return res.status(400).json({
      status: "fail",
      message: "Duplicate field value",
      code: "DUPLICATE_VALUE",
    });
  }

  // Default error response
  res.status(error.statusCode || 500).json({
    status: error.status || "error",
    message: error.message || "Something went wrong",
    code: error.code || "INTERNAL_ERROR",
    ...(process.env.NODE_ENV === "development" && { stack: error.stack }),
  });
});

// 404 handler for undefined chatbot routes
router.use("*", (req, res) => {
  res.status(404).json({
    status: "fail",
    message: `Chatbot route ${req.originalUrl} not found`,
    code: "ROUTE_NOT_FOUND",
    availableEndpoints: [
      "GET /chatbot/health",
      "GET /chatbot/debug/auth",
      "POST /chatbot/diagnose-flexible",
      "POST /chatbot/diagnose",
      "POST /chatbot/diagnose-guest",
      "GET /chatbot/history",
      "GET /chatbot/analytics",
      "POST /chatbot/new-chat",
      "DELETE /chatbot/chat/:chatId",
      "DELETE /chatbot/clear",
      "GET /chatbot/stats (admin)",
      "GET /chatbot/metrics (admin)",
    ],
  });
});

module.exports = router;
