var express = require("express");
var router = express.Router();

/* GET home page. */
router.get("/", function (req, res, next) {
  const htmlResponse = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fix My Car API</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #000;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #333;
        }
        
        .container {
            background: white;
            padding: 3rem;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            text-align: center;
            max-width: 600px;
            width: 90%;
            backdrop-filter: blur(10px);
        }
        
        .logo {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #ff6b6b, #ee5a24);
            border-radius: 50%;
            margin: 0 auto 2rem;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            color: white;
            font-weight: bold;
        }
        
        h1 {
            color: #2d3436;
            margin-bottom: 1rem;
            font-size: 2.5rem;
            font-weight: 700;
        }
        
        .subtitle {
            color: #636e72;
            font-size: 1.2rem;
            margin-bottom: 2rem;
            line-height: 1.6;
        }
        
        .status {
            background: #00b894;
            color: white;
            padding: 0.8rem 2rem;
            border-radius: 50px;
            display: inline-block;
            font-weight: 600;
            margin-bottom: 2rem;
            box-shadow: 0 4px 15px rgba(0, 184, 148, 0.3);
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
            margin: 2rem 0;
        }
        
        .info-card {
            background: #f8f9fa;
            padding: 1.5rem;
            border-radius: 15px;
            border-left: 4px solid #667eea;
        }
        
        .info-card h3 {
            color: #2d3436;
            margin-bottom: 0.5rem;
            font-size: 1.1rem;
        }
        
        .info-card p {
            color: #636e72;
            font-size: 0.95rem;
        }
        
        .endpoints {
            background: #2d3436;
            color: white;
            padding: 1.5rem;
            border-radius: 15px;
            margin: 2rem 0;
            text-align: left;
        }
        
        .endpoints h3 {
            margin-bottom: 1rem;
            color: #00b894;
        }
        
        .endpoint {
            margin: 0.8rem 0;
            font-family: 'Courier New', monospace;
            background: rgba(255, 255, 255, 0.1);
            padding: 0.5rem;
            border-radius: 5px;
            font-size: 0.9rem;
        }
        
        .method {
            color: #00b894;
            font-weight: bold;
            margin-right: 0.5rem;
        }
        
        .footer {
            margin-top: 2rem;
            padding-top: 2rem;
            border-top: 1px solid #ddd;
            color: #636e72;
            font-size: 0.9rem;
        }
        
        .tech-stack {
            display: flex;
            justify-content: center;
            gap: 1rem;
            margin: 1rem 0;
            flex-wrap: wrap;
        }
        
        .tech-item {
            background: #667eea;
            color: white;
            padding: 0.4rem 1rem;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 500;
        }
        
        @media (max-width: 768px) {
            .container {
                padding: 2rem;
                margin: 1rem;
            }
            
            h1 {
                font-size: 2rem;
            }
            
            .info-grid {
                grid-template-columns: 1fr;
                gap: 1rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">🚗</div>
        
        <h1>Fix My Car API</h1>
        <p class="subtitle">Professional automotive service management system</p>
        
        <div class="status">✅ API Status: Online</div>
        
        <div class="info-grid">
            <div class="info-card">
                <h3>🔧 Service Management</h3>
                <p>Complete automotive service booking and management system</p>
            </div>
            
            <div class="info-card">
                <h3>🔐 Secure Authentication</h3>
                <p>JWT-based authentication with role-based access control</p>
            </div>
            
            <div class="info-card">
                <h3>💳 Payment Integration</h3>
                <p>Secure payment processing with Stripe integration</p>
            </div>
            
            <div class="info-card">
                <h3>🤖 AI-Powered</h3>
                <p>Google Generative AI integration for enhanced services</p>
            </div>
        </div>
        
 
        
        <div class="tech-stack">
            <span class="tech-item">Node.js</span>
            <span class="tech-item">Express.js</span>
            <span class="tech-item">MongoDB</span>
            <span class="tech-item">JWT</span>
            <span class="tech-item">Stripe</span>
            <span class="tech-item">Google AI</span>
        </div>
        
        <div class="footer">
            
            <p><strong>Version:</strong> 1.0.0</p>
            <p><strong>Last Updated:</strong> ${new Date().toLocaleDateString()}</p>
        </div>
    </div>
</body>
</html>`;

  res.send(htmlResponse);
});

module.exports = router;
