// controller/chatbotController.js
const chatbotService = require("../services/chatbotService");
const AppError = require("../utils/appError");
const catchAsync = require("../utils/catchAsync");

// ================================
// ENHANCED CHATBOT CONTROLLERS
// ================================

/**
 * Handle AI diagnosis request for authenticated users
 * @route POST /chatbot/diagnose
 * @access Protected
 */
exports.getDiagnosis = catchAsync(async (req, res, next) => {
  const { message, chatId } = req.body;

  // Check if user exists (authentication check)
  if (!req.user || !req.user._id) {
    return next(
      new AppError("Authentication failed. Please log in again.", 401)
    );
  }

  const userId = req.user._id.toString();

  // Enhanced logging for debugging
  console.log(
    `🔧 Authenticated chatbot request from user ${userId} (${req.user.firstname} ${req.user.lastname}, ${req.user.role})`
  );
  console.log(
    `📝 Message preview: ${message.substring(0, 100)}${
      message.length > 100 ? "..." : ""
    }`
  );
  console.log(`💬 Chat ID: ${chatId || "New conversation"}`);

  // Get AI diagnosis with optional chatId
  const result = await chatbotService.getDiagnosis(
    message.trim(),
    userId,
    chatId
  );

  if (result.success) {
    console.log(
      `✅ Successful response for user ${userId}, chat: ${result.chatId}`
    );

    res.status(200).json({
      status: "success",
      data: {
        message: result.message,
        timestamp: result.timestamp,
        conversationLength: result.conversationLength,
        userId: result.userId,
        chatId: result.chatId,
        hasContext: result.hasContext,
        userName: `${req.user.firstname} ${req.user.lastname}`,
        userRole: req.user.role,
      },
    });
  } else {
    console.log(`❌ Failed response for user ${userId}: ${result.error}`);
    return next(new AppError(result.error, 400));
  }
});

/**
 * Handle AI diagnosis request for guest users (limited access)
 * @route POST /chatbot/diagnose-guest
 * @access Public
 */
exports.getGuestDiagnosis = catchAsync(async (req, res, next) => {
  const { message, guestId, chatId } = req.body;
  const sessionId =
    guestId || `guest_${req.ip.replace(/[.:]/g, "")}_${Date.now()}`;

  console.log(`🔧 Guest chatbot request from IP: ${req.ip}`);
  console.log(
    `📝 Message preview: ${message.substring(0, 100)}${
      message.length > 100 ? "..." : ""
    }`
  );
  console.log(`💬 Guest session: ${sessionId}`);

  // Get AI diagnosis with optional chatId
  const result = await chatbotService.getDiagnosis(
    message.trim(),
    sessionId,
    chatId
  );

  if (result.success) {
    console.log(`✅ Successful guest response, chat: ${result.chatId}`);

    res.status(200).json({
      status: "success",
      data: {
        message: result.message,
        timestamp: result.timestamp,
        guestId: sessionId,
        chatId: result.chatId,
        isGuest: true,
        hasContext: result.hasContext,
        note: "Sign up for unlimited access and conversation history",
        limitations: {
          maxMessages: 10,
          noPersistentHistory: true,
          limitedFeatures: true,
        },
      },
    });
  } else {
    console.log(`❌ Failed guest response: ${result.error}`);
    return next(new AppError(result.error, 400));
  }
});

/**
 * Flexible diagnosis handler that works with or without authentication
 * @route POST /chatbot/diagnose-flexible
 * @access Public/Protected (flexible)
 */
exports.getFlexibleDiagnosis = catchAsync(async (req, res, next) => {
  const { message, guestId, chatId } = req.body;

  // Determine if user is authenticated
  const isAuthenticated = req.user && req.user._id;
  const userId = isAuthenticated
    ? req.user._id.toString()
    : guestId || `guest_${req.ip.replace(/[.:]/g, "")}_${Date.now()}`;

  const userDisplay = isAuthenticated
    ? `${req.user.firstname} ${req.user.lastname} (${req.user.role})`
    : `Guest from ${req.ip}`;

  console.log(
    `🔧 ${
      isAuthenticated ? "Authenticated" : "Guest"
    } chatbot request from ${userDisplay}`
  );
  console.log(
    `📝 Message preview: ${message.substring(0, 100)}${
      message.length > 100 ? "..." : ""
    }`
  );
  console.log(`💬 Chat ID: ${chatId || "New conversation"}`);

  // Get AI diagnosis with optional chatId
  const result = await chatbotService.getDiagnosis(
    message.trim(),
    userId,
    chatId
  );

  if (result.success) {
    console.log(
      `✅ Successful ${
        isAuthenticated ? "authenticated" : "guest"
      } response, chat: ${result.chatId}`
    );

    const responseData = {
      message: result.message,
      timestamp: result.timestamp,
      userId: result.userId,
      chatId: result.chatId,
      hasContext: result.hasContext,
    };

    if (isAuthenticated) {
      responseData.conversationLength = result.conversationLength;
      responseData.userName = `${req.user.firstname} ${req.user.lastname}`;
      responseData.userRole = req.user.role;
      responseData.accountType = "authenticated";
    } else {
      responseData.isGuest = true;
      responseData.guestId = userId;
      responseData.accountType = "guest";
      responseData.note =
        "Sign up for unlimited access and conversation history";
      responseData.limitations = {
        maxMessages: 10,
        noPersistentHistory: true,
        limitedFeatures: true,
      };
    }

    res.status(200).json({
      status: "success",
      data: responseData,
    });
  } else {
    console.log(
      `❌ Failed ${isAuthenticated ? "authenticated" : "guest"} response: ${
        result.error
      }`
    );
    return next(new AppError(result.error, 400));
  }
});

/**
 * Get conversation history for current user
 * @route GET /chatbot/history
 * @access Protected
 */
exports.getConversationHistory = catchAsync(async (req, res, next) => {
  // Check if user exists
  if (!req.user || !req.user._id) {
    return next(
      new AppError("Authentication failed. Please log in again.", 401)
    );
  }

  const userId = req.user._id.toString();
  const { chatId } = req.query;

  console.log(
    `📚 History request from user ${userId} for ${
      chatId ? `chat: ${chatId}` : "all sessions"
    }`
  );

  if (chatId) {
    // Get specific chat conversation
    const conversation = await chatbotService.getChatConversation(
      userId,
      chatId
    );

    console.log(
      `📖 Retrieved conversation with ${conversation.length} messages`
    );

    res.status(200).json({
      status: "success",
      result: Math.floor(conversation.length / 2),
      data: {
        chatId: chatId,
        conversation: conversation.map((item) => ({
          role: item.role,
          content: item.content,
          timestamp: item.timestamp,
          messageId: item.messageId,
        })),
        totalExchanges: Math.floor(conversation.length / 2),
        userId: userId,
        userName: `${req.user.firstname} ${req.user.lastname}`,
      },
    });
  } else {
    // Get all chat sessions for user
    const sessions = await chatbotService.getUserChatSessions(userId);

    console.log(
      `📋 Retrieved ${sessions.length} chat sessions for user ${userId}`
    );

    res.status(200).json({
      status: "success",
      result: sessions.length,
      data: {
        sessions: sessions,
        totalSessions: sessions.length,
        userId: userId,
        userName: `${req.user.firstname} ${req.user.lastname}`,
        userRole: req.user.role,
      },
    });
  }
});

/**
 * Create a new chat session
 * @route POST /chatbot/new-chat
 * @access Protected
 */
exports.createNewChat = catchAsync(async (req, res, next) => {
  // Check if user exists
  if (!req.user || !req.user._id) {
    return next(
      new AppError("Authentication failed. Please log in again.", 401)
    );
  }

  const userId = req.user._id.toString();
  const { deviceInfo } = req.body;

  // Enhanced device info collection
  const enhancedDeviceInfo = {
    platform: req.headers["user-agent"] || "unknown",
    appVersion: deviceInfo?.appVersion || "1.0.0",
    ip: req.ip,
    timestamp: new Date().toISOString(),
    ...deviceInfo,
  };

  console.log(
    `➕ Creating new chat session for user ${userId} (${req.user.firstname} ${req.user.lastname})`
  );

  const chatId = await chatbotService.createNewChatSession(
    userId,
    enhancedDeviceInfo
  );

  if (chatId) {
    console.log(`✅ Created new chat session: ${chatId} for user ${userId}`);

    res.status(201).json({
      status: "success",
      data: {
        chatId: chatId,
        message: "New chat session created successfully",
        userId: userId,
        userName: `${req.user.firstname} ${req.user.lastname}`,
        timestamp: new Date().toISOString(),
      },
    });
  } else {
    console.log(`❌ Failed to create new chat session for user ${userId}`);
    return next(new AppError("Failed to create new chat session", 500));
  }
});

/**
 * Delete a specific chat session
 * @route DELETE /chatbot/chat/:chatId
 * @access Protected
 */
exports.deleteChatSession = catchAsync(async (req, res, next) => {
  // Check if user exists
  if (!req.user || !req.user._id) {
    return next(
      new AppError("Authentication failed. Please log in again.", 401)
    );
  }

  const userId = req.user._id.toString();
  const { chatId } = req.params;

  if (!chatId) {
    return next(new AppError("Chat ID is required", 400));
  }

  console.log(`🗑️ Deleting chat session ${chatId} for user ${userId}`);

  const deleted = await chatbotService.deleteChatSession(userId, chatId);

  console.log(
    `${
      deleted ? "✅ Successfully deleted" : "⚠️ Not found"
    } chat session ${chatId}`
  );

  res.status(200).json({
    status: "success",
    data: {
      deleted: deleted,
      message: deleted
        ? "Chat session deleted successfully"
        : "Chat session not found",
      chatId: chatId,
      userId: userId,
      userName: `${req.user.firstname} ${req.user.lastname}`,
      timestamp: new Date().toISOString(),
    },
  });
});

/**
 * Clear conversation history for current user
 * @route DELETE /chatbot/clear
 * @access Protected
 */
exports.clearConversationHistory = catchAsync(async (req, res, next) => {
  // Check if user exists
  if (!req.user || !req.user._id) {
    return next(
      new AppError("Authentication failed. Please log in again.", 401)
    );
  }

  const userId = req.user._id.toString();
  const { chatId } = req.query;

  console.log(
    `🧹 Clear request from user ${userId} for ${
      chatId ? `chat: ${chatId}` : "all conversations"
    }`
  );

  if (chatId) {
    // Clear specific chat session
    const cleared = await chatbotService.deleteChatSession(userId, chatId);

    console.log(
      `${
        cleared ? "✅ Successfully cleared" : "⚠️ Not found"
      } chat session ${chatId}`
    );

    res.status(200).json({
      status: "success",
      data: {
        cleared: cleared,
        message: cleared
          ? "Chat session cleared successfully"
          : "Chat session not found",
        chatId: chatId,
        userId: userId,
        userName: `${req.user.firstname} ${req.user.lastname}`,
        timestamp: new Date().toISOString(),
      },
    });
  } else {
    // Clear all chat sessions for user
    const cleared = await chatbotService.clearAllUserConversations(userId);

    console.log(
      `${
        cleared ? "✅ Successfully cleared" : "⚠️ No conversations found"
      } all conversations for user ${userId}`
    );

    res.status(200).json({
      status: "success",
      data: {
        cleared: cleared,
        message: cleared
          ? "All chat sessions cleared successfully"
          : "No chat sessions found",
        userId: userId,
        userName: `${req.user.firstname} ${req.user.lastname}`,
        timestamp: new Date().toISOString(),
      },
    });
  }
});

/**
 * Get chatbot service statistics (admin only)
 * @route GET /chatbot/stats
 * @access Protected + Admin
 */
exports.getServiceStats = catchAsync(async (req, res, next) => {
  // Check if user exists
  if (!req.user || !req.user._id) {
    return next(
      new AppError("Authentication failed. Please log in again.", 401)
    );
  }

  // Check if user is admin (customize based on your user model)
  const isAdmin = req.user.role === "admin" || req.user.role === "Admin";

  if (!isAdmin) {
    console.log(
      `🚫 Access denied for stats request from user ${req.user._id} (${req.user.role})`
    );
    return next(new AppError("Access denied. Admin privileges required", 403));
  }

  console.log(
    `📊 Stats request from admin ${req.user._id} (${req.user.firstname} ${req.user.lastname})`
  );

  const stats = await chatbotService.getStats();

  res.status(200).json({
    status: "success",
    data: {
      service: "Fix My Car AI Chatbot",
      version: "2.0.0",
      ...stats,
      requestedBy: {
        userId: req.user._id,
        name: `${req.user.firstname} ${req.user.lastname}`,
        role: req.user.role,
      },
      timestamp: new Date().toISOString(),
      environment: process.env.NODE_ENV,
      uptime: process.uptime(),
    },
  });
});

/**
 * Health check for chatbot service
 * @route GET /chatbot/health
 * @access Public
 */
exports.healthCheck = catchAsync(async (req, res, next) => {
  try {
    const stats = await chatbotService.getStats();

    // Simple health indicators
    const health = {
      status: "operational",
      apiKey: !!process.env.GEMINI_API_KEY,
      database: true, // Could add MongoDB connection check
      memory: stats.memory,
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      version: "2.0.0",
    };

    // Determine overall health status
    const isHealthy = health.apiKey && health.database;

    res.status(isHealthy ? 200 : 503).json({
      status: "success",
      data: {
        service: "Fix My Car AI Chatbot",
        health: {
          ...health,
          overall: isHealthy ? "healthy" : "degraded",
        },
        environment: process.env.NODE_ENV,
      },
    });
  } catch (error) {
    console.error("❌ Health check failed:", error);
    res.status(500).json({
      status: "fail",
      message: "Service health check failed",
      error: error.message,
      timestamp: new Date().toISOString(),
    });
  }
});

/**
 * Validate message input middleware
 * Can be used as middleware in routes
 */
exports.validateMessageInput = (req, res, next) => {
  const { message } = req.body;

  if (!message) {
    return res.status(400).json({
      status: "fail",
      message: "Message is required",
      code: "MESSAGE_REQUIRED",
    });
  }

  if (typeof message !== "string") {
    return res.status(400).json({
      status: "fail",
      message: "Message must be a string",
      code: "INVALID_MESSAGE_TYPE",
    });
  }

  if (message.trim().length === 0) {
    return res.status(400).json({
      status: "fail",
      message: "Message cannot be empty",
      code: "EMPTY_MESSAGE",
    });
  }

  if (message.length > 1000) {
    return res.status(400).json({
      status: "fail",
      message: "Message too long. Maximum 1000 characters allowed",
      code: "MESSAGE_TOO_LONG",
      details: {
        maxLength: 1000,
        currentLength: message.length,
      },
    });
  }

  // Clean the message and continue
  req.body.message = message.trim();
  next();
};

/**
 * Rate limiting handler for chatbot endpoints
 * Provides custom response when rate limit is exceeded
 */
exports.rateLimitHandler = (req, res) => {
  const isGuest = !req.user || !req.user._id;
  const isAuthenticated = !!req.user;

  console.log(
    `🚫 Rate limit exceeded for ${
      isAuthenticated ? `user ${req.user._id}` : `guest ${req.ip}`
    }`
  );

  res.status(429).json({
    status: "fail",
    message: isGuest
      ? "Guest limit reached. Please sign up for unlimited access."
      : "Too many requests. Please wait before trying again.",
    code: "RATE_LIMIT_EXCEEDED",
    retryAfter: Math.round(req.rateLimit?.resetTime / 1000) || 900, // 15 minutes default
    details: {
      limit: req.rateLimit?.limit,
      current: req.rateLimit?.current,
      remaining: req.rateLimit?.remaining,
      resetTime: req.rateLimit?.resetTime,
    },
    suggestions: isGuest
      ? [
          "Create an account to get higher limits",
          "Get conversation history",
          "Access premium features",
        ]
      : ["Try again in a few minutes", "Consider spacing out your requests"],
    timestamp: new Date().toISOString(),
  });
};

/**
 * Debug endpoint to check authentication status
 * @route GET /chatbot/debug/auth
 * @access Public
 */
exports.debugAuth = (req, res) => {
  const userInfo = req.user
    ? {
        id: req.user._id?.toString(),
        name: `${req.user.firstname || ""} ${req.user.lastname || ""}`.trim(),
        email: req.user.email,
        role: req.user.role,
        active: req.user.active,
        hasPassword: !!req.user.password,
        ratingsAverage: req.user.ratingsAverage,
        ratingQuantity: req.user.ratingQuantity,
        createdAt: req.user.createdAt,
      }
    : null;

  console.log(
    `🔍 Debug auth request from ${req.ip}, authenticated: ${!!req.user}`
  );

  res.status(200).json({
    status: "success",
    data: {
      isAuthenticated: !!req.user,
      user: userInfo,
      request: {
        ip: req.ip,
        userAgent: req.get("User-Agent"),
        method: req.method,
        url: req.originalUrl,
        headers: {
          authorization: req.headers.authorization ? "Present" : "Missing",
          "content-type": req.headers["content-type"],
          "user-agent": req.headers["user-agent"],
        },
      },
      environment: {
        nodeEnv: process.env.NODE_ENV,
        hasJwtSecret: !!process.env.JWT_SECRET,
        hasGeminiKey: !!process.env.GEMINI_API_KEY,
        uptime: process.uptime(),
      },
      timestamp: new Date().toISOString(),
    },
  });
};

/**
 * Get user's chatbot analytics
 * @route GET /chatbot/analytics
 * @access Protected
 */
exports.getUserAnalytics = catchAsync(async (req, res, next) => {
  if (!req.user || !req.user._id) {
    return next(
      new AppError("Authentication failed. Please log in again.", 401)
    );
  }

  const userId = req.user._id.toString();

  console.log(`📈 Analytics request from user ${userId}`);

  // Get user's chat sessions for analytics
  const sessions = await chatbotService.getUserChatSessions(userId);

  // Calculate analytics
  const analytics = {
    totalSessions: sessions.length,
    totalMessages: sessions.reduce(
      (sum, session) => sum + (session.messageCount || 0),
      0
    ),
    avgMessagesPerSession:
      sessions.length > 0
        ? Math.round(
            sessions.reduce(
              (sum, session) => sum + (session.messageCount || 0),
              0
            ) / sessions.length
          )
        : 0,
    issueCategories: sessions.reduce((acc, session) => {
      const category = session.issueCategory || "other";
      acc[category] = (acc[category] || 0) + 1;
      return acc;
    }, {}),
    lastActivity: sessions.length > 0 ? sessions[0].lastActivity : null,
    oldestSession:
      sessions.length > 0 ? sessions[sessions.length - 1].createdAt : null,
  };

  res.status(200).json({
    status: "success",
    data: {
      analytics,
      userId: userId,
      userName: `${req.user.firstname} ${req.user.lastname}`,
      timestamp: new Date().toISOString(),
    },
  });
});
